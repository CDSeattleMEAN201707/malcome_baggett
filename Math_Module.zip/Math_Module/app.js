var my_module = require('./mathlib')();
my_module.add(1, 2);
my_module.multiply(2, 2);
my_module.square(5, 5);
my_module.random(12, 55);